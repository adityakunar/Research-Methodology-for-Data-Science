

```r
# Question 2.3: Linear regression
library(foreign) #open various data files
library(car) #Package includes Levene's test 
library(tidyr)  # for wide to long format transformation of the data
library(ggplot2)
library(QuantPsyc) #include lm.beta()
library(gmodels)
library(pander) #for rendering output
library(ez) #for ezANOVA
library(lmtest)

# Getting Data:
fisherM<-read.csv("fishermen_mercury.csv", header = TRUE)
fisherM$fisherman<-factor(fisherM$fisherman, levels =c(0:1), labels =c("NotFisherman","Fisherman"))
fisherM$fishpart<-factor(fisherM$fishpart, levels =c(0:3), labels =c("none","muscle tissue", "mt or whole", "whole"))

# Analysing Data:
qqnorm(fisherM$TotHg)
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-1.png" width="672" />

```r
hist(fisherM$TotHg, 20, col="black")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-2.png" width="672" />

```r
d<-density(fisherM$TotHg)
plot(d)
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-3.png" width="672" />

```r
shapiro.test(fisherM$TotHg)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  fisherM$TotHg
## W = 0.81642, p-value = 1.047e-11
```

```r
shapiro.test(fisherM$fishmlwk)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  fisherM$fishmlwk
## W = 0.76431, p-value = 1.898e-13
```

```r
shapiro.test(fisherM$restime)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  fisherM$restime
## W = 0.77266, p-value = 3.45e-13
```

```r
shapiro.test(fisherM$weight)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  fisherM$weight
## W = 0.98449, p-value = 0.1295
```

```r
# Scatterplots:
boxplot(TotHg~fisherman, data = fisherM,main="Plot between if fisherman or not")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-4.png" width="672" />

```r
boxplot(TotHg~fishpart, data = fisherM,main="Plot between parts of fish")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-5.png" width="672" />

```r
plot(TotHg~restime, xlab="Residence time in years", ylab = "Total Mercury", data = fisherM,main="Scatterplot between Residence time and TotHg")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-6.png" width="672" />

```r
plot(TotHg~fishmlwk, xlab="Fish meals per week", ylab = "Total Mercury", data = fisherM,main="Scatterplot between Amount of fish meals and TotHg")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-7.png" width="672" />

```r
plot(TotHg~weight, xlab="Weight", ylab = "Total Mercury", data = fisherM,main="Scatterplot between Weight and TotHg")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-8.png" width="672" />

```r
plot(TotHg~age, xlab="age", ylab = "Total Mercury", data = fisherM,main="Scatterplot between age and TotHg")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-9.png" width="672" />

```r
plot(TotHg~height, xlab="height", ylab = "Total Mercury", data = fisherM,main="Scatterplot between height and TotHg")
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-10.png" width="672" />

```r
# Linear models:

model0 <-lm(TotHg~1 , data = fisherM, na.action = na.exclude)
model1 <-lm(TotHg~weight  , data = fisherM, na.action = na.exclude)
model2 <-lm(TotHg~fishmlwk , data = fisherM, na.action = na.exclude)
model3 <-lm(TotHg~restime , data = fisherM, na.action = na.exclude)
model4 <-lm(TotHg~weight+fishmlwk , data = fisherM, na.action = na.exclude)
model5 <-lm(TotHg~weight+restime , data = fisherM, na.action = na.exclude)
model6 <-lm(TotHg~fishmlwk+restime , data = fisherM, na.action = na.exclude)
model7 <-lm(TotHg~weight+fishmlwk+restime , data = fisherM, na.action = na.exclude)
modelfisherman <-lm(TotHg~fisherman+ weight+fishmlwk+restime  , data = fisherM, na.action = na.exclude)
Fullmodel <-lm(TotHg~fisherman+ weight+fishmlwk+restime+fishpart  , data = fisherM, na.action = na.exclude)

pander(anova(model0, model1, model2, model3, model4, model5, model6, model7, modelfisherman,Fullmodel))
```


-----------------------------------------------------
 Res.Df    RSS    Df   Sum of Sq     F      Pr(>F)   
-------- ------- ---- ----------- ------- -----------
  134     1157    NA      NA        NA        NA     

  133     963.3   1      193.8     30.24   2.01e-07  

  133     1051    0     -87.65      NA        NA     

  133     1153    0     -101.7      NA        NA     

  132     868.1   1      284.5     44.4    7.323e-10 

  132     962.9   0     -94.78      NA        NA     

  132     1051    0     -88.04      NA        NA     

  131     866.7   1      184.2     28.75   3.758e-07 

  130     847.4   1      19.3      3.012    0.08509  

  127     813.9   3      33.52     1.743    0.1614   
-----------------------------------------------------

Table: Analysis of Variance Table

```r
pander(summary(Fullmodel))
```


-------------------------------------------------------------------------
          &nbsp;             Estimate   Std. Error   t value   Pr(>|t|)  
--------------------------- ---------- ------------ --------- -----------
      **(Intercept)**         -10.54      2.567      -4.106    7.151e-05 

  **fishermanFisherman**      1.001       0.7326      1.366     0.1743   

        **weight**            0.1651     0.03473      4.754    5.314e-06 

       **fishmlwk**           0.0868     0.05414      1.603     0.1113   

        **restime**          -0.05237    0.04542     -1.153     0.2511   

 **fishpartmuscle tissue**     1.97        1.06       1.857     0.06557  

  **fishpartmt or whole**     0.9639      0.9793     0.9843     0.3268   

     **fishpartwhole**        1.994       1.318       1.513     0.1327   
-------------------------------------------------------------------------


--------------------------------------------------------------
 Observations   Residual Std. Error   $R^2$    Adjusted $R^2$ 
-------------- --------------------- -------- ----------------
     135               2.531          0.2966       0.2579     
--------------------------------------------------------------

Table: Fitting linear model: TotHg ~ fisherman + weight + fishmlwk + restime + fishpart

```r
pander(summary(model7))
```


---------------------------------------------------------------
     &nbsp;        Estimate   Std. Error   t value   Pr(>|t|)  
----------------- ---------- ------------ --------- -----------
 **(Intercept)**    -10.12      2.454      -4.124    6.574e-05 

   **weight**       0.1767     0.03349      5.277    5.292e-07 

  **fishmlwk**      0.1625     0.04262      3.813    0.0002105 

   **restime**     -0.02028    0.04406     -0.4603    0.6461   
---------------------------------------------------------------


-------------------------------------------------------------
 Observations   Residual Std. Error   $R^2$   Adjusted $R^2$ 
-------------- --------------------- ------- ----------------
     135               2.572          0.251       0.2338     
-------------------------------------------------------------

Table: Fitting linear model: TotHg ~ weight + fishmlwk + restime

```r
pander(summary(model4))
```


---------------------------------------------------------------
     &nbsp;        Estimate   Std. Error   t value   Pr(>|t|)  
----------------- ---------- ------------ --------- -----------
 **(Intercept)**    -10.08      2.445      -4.122    6.604e-05 

   **weight**       0.1752     0.03322      5.273    5.337e-07 

  **fishmlwk**      0.1588     0.04175      3.805    0.0002161 
---------------------------------------------------------------


--------------------------------------------------------------
 Observations   Residual Std. Error   $R^2$    Adjusted $R^2$ 
-------------- --------------------- -------- ----------------
     135               2.564          0.2498       0.2384     
--------------------------------------------------------------

Table: Fitting linear model: TotHg ~ weight + fishmlwk

```r
pander(coef(Fullmodel))
```


-----------------------------------------------------------------
 (Intercept)   fishermanFisherman   weight   fishmlwk   restime  
------------- -------------------- -------- ---------- ----------
   -10.54            1.001          0.1651    0.0868    -0.05237 
-----------------------------------------------------------------

Table: Table continues below

 
-------------------------------------------------------------
 fishpartmuscle tissue   fishpartmt or whole   fishpartwhole 
----------------------- --------------------- ---------------
         1.97                  0.9639              1.994     
-------------------------------------------------------------

```r
pander(lm.beta(model7))
```


------------------------------
 weight   fishmlwk   restime  
-------- ---------- ----------
 0.4013    0.2937    -0.03562 
------------------------------

```r
pander(lm.beta(model4))
```


-------------------
 weight   fishmlwk 
-------- ----------
 0.3978    0.2871  
-------------------

```r
pander(confint(Fullmodel))
```


------------------------------------------------
          &nbsp;              2.5 %     97.5 %  
--------------------------- ---------- ---------
      **(Intercept)**         -15.62    -5.461  

  **fishermanFisherman**     -0.4488     2.45   

        **weight**           0.09639    0.2338  

       **fishmlwk**          -0.02032   0.1939  

        **restime**          -0.1422    0.03751 

 **fishpartmuscle tissue**   -0.1287     4.068  

  **fishpartmt or whole**    -0.9739     2.902  

     **fishpartwhole**       -0.6138     4.602  
------------------------------------------------

```r
pander(confint(model7))  
```


-------------------------------------
     &nbsp;         2.5 %    97.5 %  
----------------- --------- ---------
 **(Intercept)**   -14.97    -5.265  

   **weight**      0.1105     0.243  

  **fishmlwk**     0.07819   0.2468  

   **restime**     -0.1074   0.06687 
-------------------------------------

```r
# Assumptions:
1/vif(model4)
```

```
##    weight  fishmlwk 
## 0.9984171 0.9984171
```

```r
durbinWatsonTest(model4)
```

```
##  lag Autocorrelation D-W Statistic p-value
##    1       0.2633075      1.472779       0
##  Alternative hypothesis: rho != 0
```

```r
hist(model4$residuals)
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-11.png" width="672" />

```r
hist(rstudent(model4))
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-12.png" width="672" />

```r
shapiro.test(model4$residuals)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  model4$residuals
## W = 0.85395, p-value = 3.129e-10
```

```r
plot(model4$residuals, model4$fitted)
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-13.png" width="672" />

```r
plot(model4)
```

<img src="Question3Part2_files/figure-html/unnamed-chunk-1-14.png" width="672" /><img src="Question3Part2_files/figure-html/unnamed-chunk-1-15.png" width="672" /><img src="Question3Part2_files/figure-html/unnamed-chunk-1-16.png" width="672" /><img src="Question3Part2_files/figure-html/unnamed-chunk-1-17.png" width="672" />

```r
fisherM$fitted.Hg <-fitted(model4)
pander(head(fisherM[, c("weight","fishmlwk","fitted.Hg" )], n=20L), 
       caption = "Last 20 cases and their fitted values")
```


-------------------------------
 weight   fishmlwk   fitted.Hg 
-------- ---------- -----------
   70        14        4.41    

   73        7         3.823   

   66        7         2.597   

   80        7         5.05    

   78        21        6.923   

   75        21        6.397   

   85        21        8.149   

   68        7         2.947   

   80        21        7.273   

   75        7         4.174   

   76        21        6.573   

   66        21        4.821   

   66        21        4.821   

   87        7         6.276   

   68        7         2.947   

   69        14        4.234   

   70        7         3.298   

   72        7         3.648   

   70        7         3.298   

   70        14        4.41    
-------------------------------

Table: Last 20 cases and their fitted values

```r
# Individual Cases:
#residuals
fisherM$stud.res<-rstudent(model4)
fisherM$dfbeta<-dfbeta(model4)
fisherM$leverage<-hatvalues(model4)
fisherM$cooks<-cooks.distance(model4)


troublingdata<-subset(fisherM, (leverage > 3*.022) | (abs(stud.res) > 2), 
                      select = c("leverage", "stud.res", "dfbeta"))

head(troublingdata) # i did clean for the data with high leverage and it increased the adjusted R square value.
```

```
##       leverage   stud.res dfbeta.(Intercept) dfbeta.weight dfbeta.fishmlwk
## 4  0.015274911  2.5615251      -0.4978893282  0.0074230331    0.0004422281
## 7  0.083591877  4.1619796      -1.6146691874  0.0196312178    0.0392966820
## 9  0.069123212  1.1503119      -0.2821631419  0.0031370379    0.0115373002
## 10 0.008023256  2.1104906      -0.0840397915  0.0016392389    0.0005908845
## 12 0.073254654 -0.4125989      -0.0868003314  0.0014580307   -0.0042951669
## 13 0.073254654 -1.9635298      -0.4073935989  0.0068432039   -0.0201591798
```


---
title: "Question3Part2.R"
author: "Pavel"
date: "2020-03-01"
---

