## 2.1 Conceptual model

<img src="supp-images/Q2-conceptual-model.jpg" width="672" />

We are seeking the effect of Version (0,1), Portal (consumer, customer) and their interaction on the page visits by the user.







#### Reading Data

#### We had to use file named 2 (by the %3 rule) but we used ```webvisita.csv``` as the files were named as 0, 1 and 'a' for some reason  :/

```r
data = read.csv('webvisita.csv')
data$version = as.factor(data$version)
data$portal = as.factor(data$portal)
summary(data)
```

```
##       user       version portal      pages      
##  Min.   :  1.0   0:525   0:497   Min.   : 1.00  
##  1st Qu.:250.5   1:474   1:502   1st Qu.: 1.00  
##  Median :500.0                   Median : 2.00  
##  Mean   :500.0                   Mean   : 2.71  
##  3rd Qu.:749.5                   3rd Qu.: 3.00  
##  Max.   :999.0                   Max.   :14.00
```






### 2.2 Examine the variation in Page Visits for different factors

```r
boxplot(data$version, data$pages, xlab='Version', ylab='Page Visits')
axis(side = 1, at=c(1,2), labels = c("version 0", 'version 1'))
```

<img src="Q2_files/figure-html/unnamed-chunk-1-1.png" width="672" />

#### We observe that users with version 0 have lower page visits on average as compared to those with version 1.

```r
boxplot(data$portal, data$pages, xlab='Portal', ylab='Page Visits')
axis(side = 1, at=c(1,2), labels = c("consumer", 'company'))
```

<img src="Q2_files/figure-html/unnamed-chunk-1-2.png" width="672" />

#### We observe that users with consumer portal have lower page visits on average as compared to those with company portal.

```r
plot(  density(subset(data, version == 1)$pages), col='red', 
       main="Page Visits density by Version",
       xlab = "Page Visits")
lines( density(subset(data, version == 0)$pages), col='blue')
legend(8, 0.3, legend=c("version 1", "version 0"), col=c("red", "blue"), lty=1, cex=0.8)
```

<img src="Q2_files/figure-html/unnamed-chunk-1-3.png" width="672" />

```r
plot(  density(subset(data, portal == 1)$pages), col='red',
       main="Page Visits density by Portal",
       xlab = "Page Visits")
lines( density(subset(data, portal == 0)$pages), col='blue')
legend(8, 0.35, legend=c("Company", "Consumer"), col=c("red", "blue"), lty=1, cex=0.8)
```

<img src="Q2_files/figure-html/unnamed-chunk-1-4.png" width="672" />

#### For both version and portal, the change in factor has observably different impact on page visits







### 2.2 (Extra) Performing Shapiro Wilk test to see the normalcy of versions and portal

```r
# p2 Extra, Shapiro Wilk normalcy test for Versions and Portals
library(pander)
pander(tapply(data$pages, data$version, shapiro.test))
```

```
  * **0**:

    ----------------------------------
     Test statistic       P value
    ---------------- -----------------
         0.8529       9.927e-22 * * *
    ----------------------------------

    Table: Shapiro-Wilk normality test: `X[[i]]`

  * **1**:

    ----------------------------------
     Test statistic       P value
    ---------------- -----------------
         0.8236       1.887e-22 * * *
    ----------------------------------

    Table: Shapiro-Wilk normality test: `X[[i]]`


<!-- end of list -->
```

##### Page visits distributions for both versions are not normally distributed.





```r
pander(tapply(data$pages, data$portal, shapiro.test))
```

```
* **0**:

    ---------------------------------
     Test statistic      P value
    ---------------- ----------------
         0.7953       1.53e-24 * * *
    ---------------------------------

    Table: Shapiro-Wilk normality test: `X[[i]]`

  * **1**:

    ----------------------------------
     Test statistic       P value
    ---------------- -----------------
         0.8649       2.059e-20 * * *
    ----------------------------------

    Table: Shapiro-Wilk normality test: `X[[i]]`


<!-- end of list -->
```

##### Page visits distributions for both portals are not normally distributed.

#### Page visits for both version and portal are NOT normally distributed.







### 2.3 Normalcy of Page Visits

```r
plot(density(data$pages), col='green', main="Page Visits density", xlab = "Page Visits")
lines(density(rnorm(10000*length(data$pages), mean = mean(data$pages), sd = sd(data$pages))))
legend(8, 0.25, legend=c("pages density", "normal distribution"), col=c("green", "black"), lty=1, cex=0.8)
```

<img src="Q2_files/figure-html/unnamed-chunk-1-5.png" width="672" />

##### Plot drawn just to comparatively show compared curves.

```r
shapiro.test(data$pages)
```

```
## 
## 	Shapiro-Wilk normality test
## 
## data:  data$pages
## W = 0.8436, p-value < 2.2e-16
```

#### Page Visits are NOT normally distributed.







### 2.4 Model Analysis

```r
# Model analysis
library(car) #Package includes Levene's test 
leveneTest(data$pages, interaction(data$version, data$portal))
```

```
## Levene's Test for Homogeneity of Variance (center = median)
##        Df F value Pr(>F)
## group   3  1.0835 0.3551
##       995
```

```r
bar = ggplot2::aes(data$pages, data$version, fill=data$portal)


model0 = lm(pages ~ 1, data=data)
model1 = lm(pages ~ version, data=data)
model2 = lm(pages ~ portal, data=data)
model12 = lm(pages ~ version + portal, data=data)
model123 = lm(pages ~ version + portal + version:portal, data=data)

pander(anova(model0, model1), caption="Version as main effect on Page Visits")
```

```
--------------------------------------------------
 Res.Df   RSS    Df   Sum of Sq    F      Pr(>F)  
-------- ------ ---- ----------- ------ ----------
  998     2858   NA      NA        NA       NA    

  997     2838   1      19.9      6.99   0.008324 
--------------------------------------------------

Table: Version as main effect on Page Visits
```

```r
pander(anova(model0, model2), caption="Portal as main effect on Page Visits")
```

```
----------------------------------------------------
 Res.Df   RSS    Df   Sum of Sq     F      Pr(>F)   
-------- ------ ---- ----------- ------- -----------
  998     2858   NA      NA        NA        NA     

  997     2695   1      162.9     60.28   2.033e-14 
----------------------------------------------------

Table: Portal as main effect on Page Visits
```

```r
pander(anova(model12, model123), caption="Version and Portal + Interaction")
```

```
----------------------------------------------------
 Res.Df   RSS    Df   Sum of Sq     F      Pr(>F)   
-------- ------ ---- ----------- ------- -----------
  996     2679   NA      NA        NA        NA     

  995     2593   1      86.47     33.18   1.118e-08 
----------------------------------------------------

Table: Version and Portal + Interaction
```

```r
pander(anova(model123), caption="Effect of Version + Portal + interaction on Page Visits")
```

```
-------------------------------------------------------------------
       &nbsp;         Df    Sum Sq   Mean Sq   F value    Pr(>F)   
-------------------- ----- -------- --------- --------- -----------
    **version**        1     19.9     19.9      7.636    0.005828  
    
     **portal**        1    158.6     158.6     60.86    1.546e-14 

 **version:portal**    1    86.47     86.47     33.18    1.118e-08 

   **Residuals**      995    2593     2.606      NA         NA     
-------------------------------------------------------------------

Table: Effect of Version + Portal + interaction on Page Visits
```

#### We see that Portal and Interaction have the most effect on Page Visits.







### 2.5 Simple Effect analysis

##### As the interaction is significant, we carried out a Simple Effect Analysis.

```r
# Simple Effect analysis
data$interaction = interaction(data$version, data$portal) # merge 2 factors
levels(data$interaction) # see levels of interaction
```

```
## [1] "0.0" "1.0" "0.1" "1.1"
```

```r
# create contrasts to multiply
contrastSimple = c(1,-1,0,0)
contrastComplex = c(0,0,1,-1)
SimpleEff = cbind(contrastSimple, contrastComplex)
contrasts(data$interaction) = SimpleEff
simpleEffModel = lm(pages ~ interaction, data=data)
pander(summary.lm(simpleEffModel))
```

```r
-------------------------------------------------------------------------------
             &nbsp;               Estimate   Std. Error   t value    Pr(>|t|)  
-------------------------------- ---------- ------------ --------- ------------
        **(Intercept)**            2.689      0.05118      52.54    2.964e-289 

 **interactioncontrastSimple**    -0.1701     0.07241     -2.349     0.01904   

 **interactioncontrastComplex**    0.4196     0.07235      5.799     8.94e-09  

        **interaction**            0.7676      0.1024      7.498    1.428e-13  
-------------------------------------------------------------------------------

---------------------------------------------------------------
 Observations   Residual Std. Error    $R^2$    Adjusted $R^2$ 
-------------- --------------------- --------- ----------------
     999               1.614          0.09271      0.08998     
---------------------------------------------------------------

Table: Fitting linear model: pages ~ interaction
```







### 2.6 Results

#### Article for a scientific publication

We analyzed the data and found observable impact of version and portal on page visits by their distribution. We found that neither of version, portal or page visits are normally distributed. We conducted a Model analysis and saw that all three: Version (F(1, 997) = 6.99, p. = 0.008324), Portal (F(1, 997) = 60.28 p. = 2.033e-14) and Interaction (F(1, 995) = 7.498, p. = 1.428e-13), independently have an impact on Page Visits. As the interaction effect was significant we conducted a Simple Effect analysis. It revealed a barely un-significant difference (t = -2.349, p. = 0.01904) (considering p.<0.001 as significant) for simple contrast and a more significant difference (t = 5.799, p. = 8.94e-09) for the complex contrast.
